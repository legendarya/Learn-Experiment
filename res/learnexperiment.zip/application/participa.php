<?php
class UrlController extends PageTemplate{
	function _contenido(){
		$this->page->addScript('js/behaviour.js');
		$this->page->addScript('js/ejercicio.js');
		$this->page->addScript('js/ejercicios_adicionales.js');
		$this->page->addScript('js/interfaz.js');
		$this->page->addScript('js/utilidades.js');
	
		$result = new vContainer();
		
		$result->add(new vHeader('Participa'));
		$result->add($contenido = new vSection());
		
		$contenido->add(new vParagraph('Learn Experiment pretende ser una experiencia de aprendizaje que aporte una nueva manera de adquirir conocimientos de forma más rápida efectiva y entretenida que los métodos tradicionales.'));
		$contenido->add(new vParagraph('Ademas la participación de la comunidad de usuarios contará con un papel fundamental para la evolución de los contenidos y la funcionalidad.'));
		
		$contenido->add(new vHeader('Añadir ejercicios'));
		$contenido->add(new vParagraph('Cualquier usuario registrado podrá añadir nuevos ejercicios, con lo que los contenidos van a ser creados por los propios usuarios de la página.'));
		
		$contenido->add(new vHeader('Grupos de correo'));
		
		$contenido->add(new vHeader('Learn Experiment en facebook'));
		$contenido->add(new vParagraph('En nuestra página de facebook podrás conocer a otras personas que utilizan Learn Experiment y compartir tus opiniones, experiencias y todo lo que quieras con ellas.'));
		
		$contenido->add(new vHeader('Código fuente'));
		$contenido->add(new vPreformatedText('<p>Si tienes conocimientos de programacíon en php y quieres sugerirnos alguna mejora, o simplemente ver el código completo de la web, en <a href="../programacion/">esta página</a> podras descargarlo y ejecutarlo en tu propio ordenador.<p>'));
		
		return $result;
	}
	
	function _title(){
		return '¡Participa!';
	}
	
	function comentarios_key(){
		return 'learnexperimentApartadoParticipa';
	}
}
?>