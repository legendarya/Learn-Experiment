<?php
class UrlController extends PageTemplate{
	
	function _contenido($url='',$apartado=null){
		if($apartado){
			$apartado=new Apartado($apartado);
			$result=new vHeader($apartado->nombre);
		}
		else $result=new vContainer(array(
			new vHeader('Materias'),
			$this->lista_materias()
		));
		
		return new vContainer(array(
			$this->migas($apartado),
			$result
		));
	}
	
	function lista_materias(){
		$result=new vContainer();
		
		$apartados=new Apartados();
		foreach ($apartados->padreIs(0) as $apartado){
			$subapartados=new vList();
			foreach($apartado->subapartados as $subapartado)
				$subapartados->add($this->apartadoLink($subapartado));
			$result->add(new vSection(array(new vHeader($apartado->nombre),$subapartados)));
		}
		
		return $result;
	}
	
	function apartadoLink($apartado,$clase='',$title=''){
		return new vLink(base_url().'apartado/'.str2url($apartado->nombre).'/'.$apartado->id,$apartado->nombre,$title,$clase);
	}
	
	function migas($apartado){
		$migas=new vDiv(array(
			'Estás en: ',new vLink(base_url(),'Learn Experiment'),' > ',
			($apartado?
			new vContainer(array(new vLink(base_url().'cursos/','Materias'),' > ',$apartado->nombre))
			:'Cursos')
		),'migas');
		
		if($apartado){
		$apartado_superior=$apartado->padre;
			while($apartado_superior){
				$migas->add($this->apartadoLink($apartado_superior),4);
				$migas->add(' > ',4);
				$apartado_superior=$apartado_superior->padre;
			}
		}
			
		
		return $migas;
	}
	
	function _title($url='',$apartado=null){
		if(!$apartado) return 'Cursos';
		$apartado=new Apartado($apartado);
		return $apartado->nombre;
	}
}
?>