<?php
class UrlController extends ProcessTemplate{
	function execute(){
		unset($_SESSION['id']);
		if(isset($_COOKIE['learnexperiment_name'])){
		   setcookie("learnexperiment_name", "", time()-SESSION_TIME, "/");
		   setcookie("learnexperiment_pass", "", time()-SESSION_TIME, "/");
		}
		
		redirect(base_url().'.');
	}
}
?>