<?php
class UrlController extends PageTemplate{
	function _contenido($usuario=null){
		if(!$usuario) $usuario=$this->usuario;
		else $usuario=new Usuario($usuario);
	
		return new vContainer(array(
			new vHeader('Perfil de '.$usuario->nombre_usuario)
		));
	}
	
	function _title($usuario=null){
		if(!$usuario) $usuario=$this->usuario;
		else $usuario=new Usuario($usuario);
		
		return 'Perfil de '.$usuario->nombre_usuario;
	}
}
?>