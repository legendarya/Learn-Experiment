<?php
class UrlController extends PageTemplate{
	function _contenido(){
		return new vContainer(array(
			new vHeader('Registro de usuario'),
			new vForm(array(
				new vDiv($this->error,'error'),
				new vInputText('user','Usuario:'),
				new vInputPassword('pass','Contraseña:'),
				new vInputPassword('passRepeat','Repite contraseña:')
			))
		));
	}
	
	function _processForm(){
		$usuarios=new Usuarios();
		if(!getParam('user')) $this->error = 'El campo usuario es obligatorio';
		else if(getParam('pass') != getParam('passRepeat')) $this->error = 'Los campos contraseña y repetir contraseña no coinciden.';
		else if($usuarios->where(new EqualCondition('nombre_usuario',getParam('user')))->count())
			$this->error = 'Ya existe ese usuario';
		else{
			$usuario = new Usuario();
			$usuario->nombre_usuario = getParam('user');
			$usuario->clave = getParam('pass');
			$usuario->save();
			
			$preferencia=$usuario->preferencias->add();
			$preferencia->save();
			
			$_SESSION['id'] = $usuario->id;
			
			$this->usuario=$usuario;
			if(isset($_SESSION['ejercicios']))
			foreach($_SESSION['ejercicios'] as $ejercicio)
				$this->guardaEjercicioTemporal($ejercicio);
			unset($_SESSION['ejercicios']);
			
			redirect(base_url());
		}
	}
	
	function _title(){
		return 'Registro de usuario';
	}
}
?>