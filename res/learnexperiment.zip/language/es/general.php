<?php
$interface['setup_title']='Configuración';
$interface['setup_form_button']='Guardar';
$interface['setup_database_server']='Servidor:';
$interface['setup_database']='Base de datos:';
$interface['setup_database_user']='Usuario:';
$interface['setup_database_password']='Contraseña:';
$interface['setup_facebook_api']='Facebook API:';
$interface['setup_facebook_secret']='Facebook secret:';
$interface['setup_error_connect']='No se ha podido conectar a la base de datos, comprueba que el servidor, el usuario y la contraseña son correctos';
$interface['setup_error_database_required']='Debes indicar el nombre de la base de datos';
$interface['setup_error_database']='No se ha podido seleccionar la base de datos, comprueba que es correcta';
?>