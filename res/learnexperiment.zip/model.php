<?php
require_once 'model.php';

global $entity_usuario;
$entity_usuario =new entity ('usuario');
$entity_usuario->addField(new TextField('nombre_usuario'));
$entity_usuario->addField(new PasswordField('clave'));
$entity_usuario->addField(new TextField('facebook'));
$entity_usuario->addField(new IntegerField('administrador'));

class Usuario extends Persistent{
	function __construct($condition=null){
		parent::__construct('usuario',$condition);
	}
}

class Usuarios extends PersistentList{
	function __construct(){
		$this->table='usuario';
	}
}

global $entity_usuario;
$entity_curso=new entity ('aprender_curso');
$entity_curso->addField(new TextField('nombre'));
$entity_curso->addField(new IntegerField('activo'));
$entity_curso->addField(new TextField('url'));
$entity_curso->addField(new DateField('fecha_actualizacion'));

class Curso extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_curso',$condition);
	}
}

class Cursos extends PersistentList{
	function __construct(){
		$this->table='aprender_curso';
	}
}

$entity_preferencias=new entity ('aprender_preferencias');
$entity_preferencias->addField(new IntegerField('enter'));
$entity_preferencias->addField(new IntegerField('ignorar_signos'));
$entity_usuario->addSet('preferencias',$entity_preferencias,'usuario');

class Preferencia extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_preferencias',$condition);
	}
}

$entity_articulo=new entity ('aprender_articulo');
$entity_articulo->addField(new TextField('titulo'));
$entity_articulo->addField(new TextField('dir'));
$entity_articulo->addField(new TextField('texto'));
$entity_articulo->addField(new IntegerField('ocultar_ejercicio'));

$entity_articulo->addSet('articulos',$entity_articulo,'padre');

class Articulo extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_articulo',$condition);
	}
}


$entity_historial=new entity ('aprender_historial');
$entity_historial->addField(new IntegerField('estado'));
$entity_historial->addField(new DateField('fecha'));
$entity_historial->addField(new StructField('texto'));
$entity_historial->addField(new TextField('motivo'));

$entity_historial->addSet('subversiones',$entity_historial,'padre');
$entity_usuario->addSet('subversiones',$entity_historial,'usuario');

class Version extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_historial',$condition);
	}
}

class Historial extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_historial',$condition);
	}
}

class Versiones extends PersistentList{
	function __construct(){
		$this->table='aprender_historial';}}


$entity_teclado=new entity ('aprender_teclado');
$entity_teclado->addField(new TextField('nombre'));
$entity_teclado->addField(new TextField('teclado'));

$entity_curso->addSet('teclados',$entity_teclado,'curso');

class Teclado extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_teclado',$condition);
	}
}

class Teclados extends PersistentList{
	function __construct(){
		$this->table='aprender_teclado';}}

global $entity_apartado_curso;
$entity_apartado_curso=new entity ('aprender_apartado_curso');
$entity_apartado_curso->addField(new TextField('nombre'));
$entity_apartado_curso->addField(new TextField('resumen'));
$entity_apartado_curso->addField(new TextField('descripcion'));
$entity_apartado_curso->addList('subapartados',$entity_apartado_curso,'padre');
$entity_apartado_curso->addField(new DateField('fecha_actualizacion'));

$entity_curso->addSet('apartados',$entity_apartado_curso,'curso');

class Apartado extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_apartado_curso',$condition);
	}
}

class Apartados extends PersistentList{
	function __construct(){
		$this->table='aprender_apartado_curso';}}

$entity_responsable_apartado=new entity('responsable_apartado');
$entity_apartado_curso->addSet('responsables',$entity_responsable_apartado,'apartado');
$entity_usuario->addSet('apartados_responsable',$entity_responsable_apartado,'usuario');
		
$entity_tabla_equivalencia=new entity ('aprender_tabla_equivalencia');
$entity_tabla_equivalencia->addField(new TextField('titulo'));
$entity_tabla_equivalencia->addField(new TextField('tabla'));

$entity_apartado_curso->addSet('tablas_equivalencia',$entity_tabla_equivalencia,'apartado');

class TablaEquivalencia extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_tabla_equivalencia',$condition);
	}
}

class TablasEquivalencia extends PersistentList{
	function __construct(){
		$this->table='aprender_tabla_equivalencia';}}

		

$entity_idioma=new entity ('idioma');
$entity_idioma->addField(new TextField('codigo'));
$entity_idioma->addField(new TextField('nombre'));

class Idioma extends Persistent{
	function __construct($condition=null){
		parent::__construct('idioma',$condition);
	}
}

class Idiomas extends PersistentList{
	function __construct(){
		$this->table='idioma';
	}
}
		
$entity_ejercicio=new entity ('aprender_leccion');
$entity_ejercicio->addField(new TextField('titulo'));
$entity_ejercicio->addField(new TextField('descripcion'));
$entity_ejercicio->addField(new TextField('url'));
$entity_ejercicio->addField(new IntegerField('nivel'));
$entity_ejercicio->addField(new IntegerField('tipo'));
$entity_ejercicio->addField(new IntegerField('fecha_publicacion'));
$entity_ejercicio->addField(new DateField('fecha_actualizacion'));
$entity_ejercicio->addField(new TextField('video'));
$entity_ejercicio->addField(new TextField('contenido_externo'));
$entity_ejercicio->addField(new IntegerField('ordenar'));
$entity_ejercicio->addField(new IntegerField('pronuncia_pregunta'));
$entity_ejercicio->addField(new IntegerField('pronuncia_respuesta'));

$entity_apartado_curso->addList('ejercicios',$entity_ejercicio,'apartado');
$entity_curso->addSet('ejercicios',$entity_ejercicio,'curso');
$entity_teclado->addSet('ejercicios',$entity_ejercicio,'teclado');
$entity_usuario->addSet('ejercicios_creados',$entity_ejercicio,'director');

$entity_ejercicio->addSet('articulos',$entity_articulo,'ejercicio');
$entity_ejercicio->addSet('versiones',$entity_historial,'ejercicio');

$entity_idioma->addSet('pronuncia_preguntas',$entity_ejercicio,'idioma_pregunta');
$entity_idioma->addSet('pronuncia_respuestas',$entity_ejercicio,'idioma_respuesta');

$entity_ejercicio->addField(new ReferenceField('version',$entity_historial));

class Leccion extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_leccion',$condition);
	}
}

class Ejercicio extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_leccion',$condition);
	}
}

class Ejercicios extends PersistentList{
	function __construct(){
		$this->table='aprender_leccion';
	}
}

$entity_pregunta=new entity ('aprender_pregunta');
$entity_pregunta->addField(new TextField('pregunta'));
$entity_pregunta->addField(new TextField('respuesta'));
$entity_pregunta->addField(new StructField('opciones'));

$entity_ejercicio->addSet('preguntas',$entity_pregunta,'leccion');

class PreguntaLeccion extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_pregunta',$condition);
	}
}

class Preguntas extends PersistentList{
	function __construct(){
		$this->table='aprender_pregunta';
	}
}

$entity_estado_leccion=new entity ('aprender_leccion_estado');
$entity_estado_leccion->addField(new FloatField('mejor_porcentaje'));
$entity_estado_leccion->addField(new FloatField('ultimo_porcentaje'));
$entity_estado_leccion->addField(new IntegerField('mejor_fallos'));
$entity_estado_leccion->addField(new IntegerField('ultimo_fallos'));
$entity_estado_leccion->addField(new IntegerField('mejor_tiempo'));
$entity_estado_leccion->addField(new IntegerField('ultimo_tiempo'));
$entity_estado_leccion->addField(new DateField('repaso_anterior'));
$entity_estado_leccion->addField(new StructField('preguntas'));

$entity_articulo->addSet('usuarios',$entity_estado_leccion,'articulo');
$entity_ejercicio->addSet('usuarios',$entity_estado_leccion,'leccion');
$entity_usuario->addSet('ejercicios',$entity_estado_leccion,'usuario');

class EstadoLeccion extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_leccion_estado',$condition);
	}
}

$entity_noticia=new entity ('noticia');
$entity_noticia->addField(new TextField('titulo'));
$entity_noticia->addField(new TextField('texto'));
$entity_noticia->addField(new DateField('fecha'));

class Noticia extends Persistent{
	function __construct($condition=null){
		parent::__construct('noticia',$condition);
	}
}

class Noticias extends PersistentList{
	function __construct(){
		$this->table='noticia';
	}
}

$entity_foro=new entity ('foro');
$entity_foro->addField(new TextField('nombre'));
$entity_foro->addField(new TextField('descripcion'));
$entity_foro->addField(new IntegerField('orden'));
$entity_foro->addField(new IntegerField('noticias'));

class Foro extends Persistent{
	function __construct($condition=null){
		parent::__construct('foro',$condition);
	}
}

class Foros extends PersistentList{
	function __construct(){
		$this->table='foro';
	}
}

$entity_tema=new entity ('tema');
$entity_tema->addField(new TextField('titulo'));
$entity_tema->addField(new DateField('fecha'));
$entity_tema->addField(new DateField('fecha_creacion'));

$entity_foro->addSet('temas',$entity_tema,'foro');

class Tema extends Persistent{
	function __construct($condition=null){
		parent::__construct('tema',$condition);
	}
}

class Temas extends PersistentList{
	function __construct(){
		$this->table='tema';
	}
}

$entity_mensaje=new entity ('mensaje');
$entity_mensaje->addField(new TextField('mensaje'));
$entity_mensaje->addField(new TextField('nombre'));
$entity_mensaje->addField(new DateField('fecha'));

$entity_usuario->addSet('mensajes',$entity_mensaje,'usuario');
$entity_tema->addSet('mensajes',$entity_mensaje,'tema');

$entity_tema->addField(new ReferenceField('ultimoMensaje',$entity_mensaje));
$entity_foro->addField(new ReferenceField('ultimoMensaje',$entity_mensaje));

class Mensaje extends Persistent{
	function __construct($condition=null){
		parent::__construct('mensaje',$condition);
	}
}

class Mensajes extends PersistentList{
	function __construct(){
		$this->table='mensaje';
	}
}

$entity_ultima_lectura=new entity ('aprender_ultima_lectura');
$entity_ultima_lectura->addField(new DateField('fecha'));

$entity_usuario->addSet('temasLeidos',$entity_ultima_lectura,'usuario');
$entity_tema->addSet('temasLeidos',$entity_ultima_lectura,'tema');

class LecturaTema extends Persistent{
	function __construct($condition=null){
		parent::__construct('aprender_ultima_lectura',$condition);
	}
}

class LecturasTema extends PersistentList{
	function __construct(){
		$this->table='aprender_ultima_lectura';
	}
}
?>